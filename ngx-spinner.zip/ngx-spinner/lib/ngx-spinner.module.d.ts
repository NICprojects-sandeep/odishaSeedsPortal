import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './ngx-spinner.component';
import * as ɵngcc2 from '@angular/common';
export declare class NgxSpinnerModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<NgxSpinnerModule, [typeof ɵngcc1.NgxSpinnerComponent], [typeof ɵngcc2.CommonModule], [typeof ɵngcc1.NgxSpinnerComponent]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<NgxSpinnerModule>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmd4LXNwaW5uZXIubW9kdWxlLmQudHMiLCJzb3VyY2VzIjpbIm5neC1zcGlubmVyLm1vZHVsZS5kLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBOzs7QUFDQSIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBkZWNsYXJlIGNsYXNzIE5neFNwaW5uZXJNb2R1bGUge1xufVxuIl19