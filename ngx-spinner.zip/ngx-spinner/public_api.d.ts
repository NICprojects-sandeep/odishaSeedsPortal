export * from './lib/ngx-spinner.service';
export * from './lib/ngx-spinner.component';
export * from './lib/ngx-spinner.module';
